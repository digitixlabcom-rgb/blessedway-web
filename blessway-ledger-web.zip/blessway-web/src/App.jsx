import React, { useState, useEffect, useMemo } from "react";
import {
  Truck, Users, FileText, Wallet, BarChart3, Plus, Trash2, Printer,
  ChevronRight, X, LogOut, ShieldCheck, AlertCircle, Search, CheckCircle2,
  ArrowUpRight, ArrowDownRight, RefreshCw, Receipt, TrendingUp, TrendingDown, Wrench
} from "lucide-react";

/* ---------------------------------------------------------------
   BLESS WAY — Fleet, Client Ledger & Invoicing
   Palette: Ink #14213D / Slate #4A5568 / Paper #F7F6F3 / Amber #FFB703
            Success #2A9D8F / Hairline #E2E1DC
   Type: Space Grotesk (display) / Inter (body) / IBM Plex Mono (figures)
--------------------------------------------------------------- */

const COMPANY = {
  name: "Bless Way General Transport & Contracting L.L.C - S.P.C",
  address: "Mussafah 37, Abu Dhabi, U.A.E.",
  email: "blessway.generaltransport@gmail.com",
  mobile: "+971 50 257 6455",
  trn: "10523906380000",
  bank: {
    accountNumber: "14467956920001",
    accountName: "BLESS WAY GEN TRN CNTRCT L.L.C - S.P.C",
    iban: "AE820030014467956920001",
  },
};

const STORAGE_KEY = "blessway:data:v1";
const UNITS = ["month", "day", "week", "trip"];

const uid = () => Math.random().toString(36).slice(2, 10);
const todayISO = () => new Date().toISOString().slice(0, 10);

function formatAED(n) {
  const v = Number(n || 0);
  return `AED ${v.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

/* ---------- number to words (AED) ---------- */
function numberToWords(num) {
  const ones = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
    "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
  const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
  function chunk(n) {
    if (n === 0) return "";
    if (n < 20) return ones[n] + " ";
    if (n < 100) return tens[Math.floor(n / 10)] + " " + chunk(n % 10);
    return ones[Math.floor(n / 100)] + " Hundred " + chunk(n % 100);
  }
  function full(n) {
    if (n === 0) return "Zero";
    let str = "";
    const crore = Math.floor(n / 10000000); n %= 10000000;
    const lakh = Math.floor(n / 100000); n %= 100000;
    const thousand = Math.floor(n / 1000); n %= 1000;
    if (crore) str += chunk(crore) + "Crore ";
    if (lakh) str += chunk(lakh) + "Lakh ";
    if (thousand) str += chunk(thousand) + "Thousand ";
    if (n) str += chunk(n);
    return str.trim();
  }
  const whole = Math.floor(Math.abs(num));
  const fils = Math.round((Math.abs(num) - whole) * 100);
  let words = full(whole) + " Dirham";
  if (fils > 0) words += " and " + full(fils) + " Fils";
  return words + " Only.";
}

/* ---------- seed data (grounded in the client's real fleet/invoices) ---------- */
function seedData() {
  return {
    nextInvoiceSeq: 118,
    users: [
      { id: uid(), name: "Client Owner", role: "admin", pin: "1111" },
      { id: uid(), name: "Staff", role: "staff", pin: "2222" },
    ],
    vehicles: [
      { id: uid(), vehicleNo: "83979", make: "Ashok Leyland Falcon Mark-I", seatingCapacity: 66, monthlyRate: 8500, dailyRate: 250 },
      { id: uid(), vehicleNo: "47341", make: "Ashok Leyland Falcon Mark-I", seatingCapacity: 66, monthlyRate: 8500, dailyRate: 250 },
      { id: uid(), vehicleNo: "18254", make: "Ashok Leyland Falcon Mark-I", seatingCapacity: 66, monthlyRate: 8500, dailyRate: 250 },
    ],
    clients: [
      { id: uid(), name: "NSON Construction LLC", address: "Industrial City Abu Dhabi 3, P.O. Box 26831", phone: "045706037", trn: "100551301300003" },
    ],
    invoices: [],
    payments: [],
    expenses: [],
  };
}

const EXPENSE_CATEGORIES = ["Vehicle Maintenance", "Fuel", "Utility Bills", "Office Expenses", "Salaries", "Insurance", "Other"];

/* ---------- storage helpers (browser localStorage for now — swap for Supabase in production, see README) ---------- */
async function loadData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
}
async function saveData(data) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

/* ================= APP ================= */
export default function App() {
  const [data, setData] = useState(null);
  const [status, setStatus] = useState("loading"); // loading | ready | error
  const [user, setUser] = useState(null);
  const [page, setPage] = useState("dashboard");
  const [toast, setToast] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        let d = await loadData();
        if (!d) { d = seedData(); await saveData(d); }
        if (!d.expenses) { d.expenses = []; await saveData(d); }
        setData(d);
        setStatus("ready");
      } catch (e) {
        setStatus("error");
      }
    })();
  }, []);

  async function persist(next) {
    setData(next);
    try { await saveData(next); }
    catch (e) { showToast("Couldn't save — check connection and try again.", true); }
  }

  function showToast(msg, isError = false) {
    setToast({ msg, isError });
    setTimeout(() => setToast(null), 3200);
  }

  if (status === "loading") {
    return (
      <div style={{ background: "#F7F6F3" }} className="min-h-[600px] flex items-center justify-center font-sans">
        <div className="flex items-center gap-3 text-[#4A5568]">
          <RefreshCw className="animate-spin" size={20} />
          <span>Loading Bless Way ledger…</span>
        </div>
      </div>
    );
  }
  if (status === "error") {
    return (
      <div style={{ background: "#F7F6F3" }} className="min-h-[600px] flex items-center justify-center font-sans">
        <div className="text-center text-[#4A5568]">
          <AlertCircle className="mx-auto mb-2 text-[#B3261E]" />
          Couldn't load data. Please refresh.
        </div>
      </div>
    );
  }

  if (!user) return <LoginGate users={data.users} onLogin={setUser} />;

  return (
    <div style={{ background: "#F7F6F3", fontFamily: "Inter, sans-serif" }} className="min-h-[700px] text-[#14213D] flex">
      <style>{FONT_IMPORTS + PRINT_CSS}</style>
      <Sidebar page={page} setPage={setPage} user={user} onLogout={() => setUser(null)} />
      <main className="flex-1 min-w-0">
        <TopBar user={user} data={data} />
        <div className="p-6 max-w-6xl mx-auto">
          {page === "dashboard" && <Dashboard data={data} setPage={setPage} />}
          {page === "vehicles" && <VehiclesPage data={data} persist={persist} showToast={showToast} user={user} />}
          {page === "clients" && <ClientsPage data={data} persist={persist} showToast={showToast} user={user} />}
          {page === "invoices" && <InvoicesPage data={data} persist={persist} showToast={showToast} />}
          {page === "payments" && <PaymentsPage data={data} persist={persist} showToast={showToast} />}
          {page === "statements" && <StatementsPage data={data} />}
          {page === "expenses" && <ExpensesPage data={data} persist={persist} showToast={showToast} />}
          {page === "profitloss" && <ProfitLossPage data={data} />}
        </div>
      </main>
      {toast && (
        <div className={`no-print fixed bottom-6 right-6 px-4 py-3 rounded-lg shadow-lg text-sm text-white flex items-center gap-2 ${toast.isError ? "bg-[#B3261E]" : "bg-[#2A9D8F]"}`}>
          {toast.isError ? <AlertCircle size={16} /> : <CheckCircle2 size={16} />}
          {toast.msg}
        </div>
      )}
    </div>
  );
}

const FONT_IMPORTS = `
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&family=IBM+Plex+Mono:wght@500;600&display=swap');
.font-display{font-family:'Space Grotesk',sans-serif;}
.font-mono{font-family:'IBM Plex Mono',monospace;}
`;
const PRINT_CSS = `
@media print {
  .no-print { display: none !important; }
  .print-area { position: absolute; inset: 0; width: 100%; }
  body { background: white !important; }
}
.input{width:100%;border:1px solid #E2E1DC;border-radius:8px;padding:8px 10px;background:white;font-size:14px;outline:none}
.input:focus{box-shadow:0 0 0 2px #FFB703}
.label{font-size:11px;font-weight:500;color:#4A5568;text-transform:uppercase;letter-spacing:0.02em}
`;

/* ---------------- Logo ---------------- */
function Logo({ size = 36 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <circle cx="24" cy="16" r="10" fill="#FFB703" opacity="0.9" />
      <rect x="6" y="22" width="36" height="16" rx="4" fill="#14213D" />
      <rect x="10" y="26" width="7" height="6" rx="1" fill="#F7F6F3" />
      <rect x="19" y="26" width="7" height="6" rx="1" fill="#F7F6F3" />
      <circle cx="14" cy="40" r="3" fill="#14213D" />
      <circle cx="34" cy="40" r="3" fill="#14213D" />
      <path d="M6 30h36" stroke="#FFB703" strokeWidth="2" />
    </svg>
  );
}

/* ---------------- Login ---------------- */
function LoginGate({ users, onLogin }) {
  const [selected, setSelected] = useState(users[0]?.id || "");
  const [pin, setPin] = useState("");
  const [err, setErr] = useState("");
  const chosen = users.find((u) => u.id === selected);

  function submit(e) {
    e.preventDefault();
    if (chosen && chosen.pin === pin) { onLogin(chosen); }
    else setErr("Incorrect PIN.");
  }

  return (
    <div style={{ background: "#14213D" }} className="min-h-[700px] flex items-center justify-center font-sans p-6">
      <style>{FONT_IMPORTS}</style>
      <form onSubmit={submit} className="bg-[#F7F6F3] rounded-2xl shadow-2xl p-8 w-full max-w-sm">
        <div className="flex items-center gap-3 mb-1">
          <Logo />
          <div>
            <div className="font-display font-semibold text-[#14213D] leading-tight">Bless Way</div>
            <div className="text-xs text-[#4A5568]">Transport & Contracting</div>
          </div>
        </div>
        <div className="h-px bg-[#E2E1DC] my-5" />
        <label className="text-xs font-medium text-[#4A5568] uppercase tracking-wide">Sign in as</label>
        <select
          className="w-full mt-1 mb-4 border border-[#E2E1DC] rounded-lg px-3 py-2 bg-white outline-none focus:ring-2 focus:ring-[#FFB703]"
          value={selected} onChange={(e) => { setSelected(e.target.value); setErr(""); }}
        >
          {users.map((u) => <option key={u.id} value={u.id}>{u.name} — {u.role === "admin" ? "Admin" : "Staff"}</option>)}
        </select>
        <label className="text-xs font-medium text-[#4A5568] uppercase tracking-wide">PIN</label>
        <input
          type="password" inputMode="numeric" value={pin} maxLength={6}
          onChange={(e) => { setPin(e.target.value); setErr(""); }}
          className="w-full mt-1 border border-[#E2E1DC] rounded-lg px-3 py-2 bg-white outline-none focus:ring-2 focus:ring-[#FFB703] font-mono tracking-widest"
          placeholder="••••"
        />
        {err && <div className="text-[#B3261E] text-xs mt-2">{err}</div>}
        <button className="mt-5 w-full bg-[#14213D] hover:bg-[#1d2f57] text-white rounded-lg py-2.5 font-medium flex items-center justify-center gap-2 transition">
          <ShieldCheck size={16} /> Sign in
        </button>
        <p className="text-[11px] text-[#4A5568] mt-4 leading-relaxed">
          Demo PINs — Admin: 1111 · Staff: 2222. Change these in Settings once your client is set up (see note in chat about production-grade login).
        </p>
      </form>
    </div>
  );
}

/* ---------------- Sidebar / TopBar ---------------- */
function Sidebar({ page, setPage, user, onLogout }) {
  const items = [
    { id: "dashboard", label: "Dashboard", icon: BarChart3 },
    { id: "vehicles", label: "Fleet", icon: Truck },
    { id: "clients", label: "Clients", icon: Users },
    { id: "invoices", label: "Invoices", icon: FileText },
    { id: "payments", label: "Payments", icon: Wallet },
    { id: "statements", label: "Statements", icon: FileText },
    { id: "expenses", label: "Expenses", icon: Receipt },
    { id: "profitloss", label: "Profit & Loss", icon: TrendingUp },
  ];
  return (
    <aside style={{ background: "#14213D" }} className="no-print w-60 shrink-0 min-h-[700px] text-white flex flex-col">
      <div className="flex items-center gap-2.5 px-5 py-5">
        <Logo size={32} />
        <div>
          <div className="font-display font-semibold text-sm leading-tight">Bless Way</div>
          <div className="text-[10px] text-[#9AA5C0]">Fleet & Ledger</div>
        </div>
      </div>
      <nav className="flex-1 px-3 space-y-0.5">
        {items.map((it) => {
          const Icon = it.icon;
          const active = page === it.id;
          return (
            <button key={it.id} onClick={() => setPage(it.id)}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm transition relative
                ${active ? "bg-white/10 text-white" : "text-[#B7C0DA] hover:bg-white/5 hover:text-white"}`}>
              {active && <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-5 bg-[#FFB703] rounded-r" />}
              <Icon size={16} /> {it.label}
            </button>
          );
        })}
      </nav>
      <div className="px-3 pb-4">
        <div className="px-3 py-2 text-xs text-[#9AA5C0]">{user.name} · {user.role === "admin" ? "Admin" : "Staff"}</div>
        <button onClick={onLogout} className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-[#B7C0DA] hover:bg-white/5 hover:text-white">
          <LogOut size={15} /> Sign out
        </button>
      </div>
    </aside>
  );
}

function TopBar({ user, data }) {
  const outstanding = useMemo(() => totalOutstanding(data), [data]);
  return (
    <div className="no-print border-b border-[#E2E1DC] bg-white/70 backdrop-blur px-6 py-3 flex items-center justify-between">
      <div className="text-sm text-[#4A5568]">Saved on this device/browser · see README for multi-device sync</div>
      <div className="flex items-center gap-2 text-sm">
        <span className="text-[#4A5568]">Outstanding</span>
        <span className="font-mono font-semibold text-[#B3261E]">{formatAED(outstanding)}</span>
      </div>
    </div>
  );
}

function totalOutstanding(data) {
  const invoiced = data.invoices.reduce((s, i) => s + i.total, 0);
  const received = data.payments.reduce((s, p) => s + p.amount, 0);
  return Math.max(0, invoiced - received);
}
// Revenue for P&L purposes is the pre-VAT subtotal — VAT collected is owed to the
// government, not company income, so it's excluded from profit calculations.
function totalRevenue(data) {
  return data.invoices.reduce((s, i) => s + i.subtotal, 0);
}
function totalExpenses(data) {
  return (data.expenses || []).reduce((s, e) => s + e.amount, 0);
}
function netProfit(data) {
  return totalRevenue(data) - totalExpenses(data);
}
function monthKey(dateStr) { return (dateStr || "").slice(0, 7); } // YYYY-MM

/* ---------------- Dashboard ---------------- */
function Dashboard({ data, setPage }) {
  const invoicedTotal = data.invoices.reduce((s, i) => s + i.total, 0);
  const receivedTotal = data.payments.reduce((s, p) => s + p.amount, 0);
  const outstanding = Math.max(0, invoicedTotal - receivedTotal);
  const profit = netProfit(data);
  const recent = [...data.invoices].sort((a, b) => (a.date < b.date ? 1 : -1)).slice(0, 5);

  const cards = [
    { label: "Fleet", value: data.vehicles.length, icon: Truck, page: "vehicles" },
    { label: "Clients", value: data.clients.length, icon: Users, page: "clients" },
    { label: "Total Invoiced", value: formatAED(invoicedTotal), icon: FileText, page: "invoices", mono: true },
    { label: "Total Received", value: formatAED(receivedTotal), icon: ArrowDownRight, page: "payments", mono: true, tone: "#2A9D8F" },
    { label: "Outstanding", value: formatAED(outstanding), icon: ArrowUpRight, page: "statements", mono: true, tone: "#B3261E" },
    { label: "Net Profit (all-time)", value: formatAED(profit), icon: profit >= 0 ? TrendingUp : TrendingDown, page: "profitloss", mono: true, tone: profit >= 0 ? "#2A9D8F" : "#B3261E" },
  ];

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold mb-6">Overview</h1>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <button key={c.label} onClick={() => setPage(c.page)} className="text-left bg-white border border-[#E2E1DC] rounded-xl p-4 hover:border-[#FFB703] transition">
              <div className="flex items-center justify-between mb-3">
                <div className="w-8 h-8 rounded-lg bg-[#F7F6F3] flex items-center justify-center"><Icon size={16} color={c.tone || "#14213D"} /></div>
                <ChevronRight size={14} className="text-[#B7C0DA]" />
              </div>
              <div className={`text-lg font-semibold ${c.mono ? "font-mono" : "font-display"}`} style={{ color: c.tone || "#14213D" }}>{c.value}</div>
              <div className="text-xs text-[#4A5568] mt-0.5">{c.label}</div>
            </button>
          );
        })}
      </div>

      <h2 className="font-display text-lg font-semibold mb-3">Recent invoices</h2>
      <div className="bg-white border border-[#E2E1DC] rounded-xl overflow-hidden">
        {recent.length === 0 ? (
          <div className="p-6 text-sm text-[#4A5568]">No invoices yet — create your first one from the Invoices tab.</div>
        ) : recent.map((inv) => {
          const client = data.clients.find((c) => c.id === inv.clientId);
          return (
            <div key={inv.id} className="flex items-center justify-between px-4 py-3 border-b border-[#E2E1DC] last:border-0 text-sm">
              <div>
                <div className="font-mono font-medium">{inv.invoiceNo}</div>
                <div className="text-[#4A5568] text-xs">{client?.name || "—"} · {inv.date}</div>
              </div>
              <div className="font-mono font-semibold">{formatAED(inv.total)}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------------- Vehicles ---------------- */
function VehiclesPage({ data, persist, showToast, user }) {
  const [form, setForm] = useState(null);

  function startNew() { setForm({ id: null, vehicleNo: "", make: "", seatingCapacity: "", monthlyRate: "", dailyRate: "" }); }
  function edit(v) { setForm(v); }
  function remove(id) {
    if (!confirm("Remove this vehicle?")) return;
    persist({ ...data, vehicles: data.vehicles.filter((v) => v.id !== id) });
    showToast("Vehicle removed.");
  }
  function save(e) {
    e.preventDefault();
    if (!form.vehicleNo || !form.make) return showToast("Vehicle No and Make are required.", true);
    const clean = { ...form, seatingCapacity: Number(form.seatingCapacity) || 0, monthlyRate: Number(form.monthlyRate) || 0, dailyRate: Number(form.dailyRate) || 0 };
    let vehicles;
    if (clean.id) vehicles = data.vehicles.map((v) => (v.id === clean.id ? clean : v));
    else vehicles = [...data.vehicles, { ...clean, id: uid() }];
    persist({ ...data, vehicles });
    setForm(null);
    showToast("Vehicle saved.");
  }

  return (
    <div>
      <PageHeader title="Fleet" subtitle="Vehicle No, make, seating capacity, monthly & daily rates.">
        {user.role === "admin" && <PrimaryButton onClick={startNew}><Plus size={15} /> Add vehicle</PrimaryButton>}
      </PageHeader>

      <div className="bg-white border border-[#E2E1DC] rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-[#4A5568] uppercase tracking-wide bg-[#F7F6F3]">
              <th className="px-4 py-2.5">Vehicle No</th><th className="px-4 py-2.5">Make</th>
              <th className="px-4 py-2.5">Seats</th><th className="px-4 py-2.5">Monthly Rate</th>
              <th className="px-4 py-2.5">Daily Rate</th><th className="px-4 py-2.5"></th>
            </tr>
          </thead>
          <tbody>
            {data.vehicles.map((v) => (
              <tr key={v.id} className="border-t border-[#E2E1DC]">
                <td className="px-4 py-2.5 font-mono">{v.vehicleNo}</td>
                <td className="px-4 py-2.5">{v.make}</td>
                <td className="px-4 py-2.5">{v.seatingCapacity}</td>
                <td className="px-4 py-2.5 font-mono">{formatAED(v.monthlyRate)}</td>
                <td className="px-4 py-2.5 font-mono">{formatAED(v.dailyRate)}</td>
                <td className="px-4 py-2.5 text-right">
                  {user.role === "admin" && (
                    <div className="flex justify-end gap-2">
                      <button onClick={() => edit(v)} className="text-xs text-[#14213D] underline">Edit</button>
                      <button onClick={() => remove(v.id)} className="text-[#B3261E]"><Trash2 size={14} /></button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
            {data.vehicles.length === 0 && <tr><td colSpan={6} className="px-4 py-6 text-center text-[#4A5568]">No vehicles yet.</td></tr>}
          </tbody>
        </table>
      </div>

      {form && (
        <Modal onClose={() => setForm(null)} title={form.id ? "Edit vehicle" : "Add vehicle"}>
          <form onSubmit={save} className="space-y-3">
            <Field label="Vehicle No"><input className="input" value={form.vehicleNo} onChange={(e) => setForm({ ...form, vehicleNo: e.target.value })} /></Field>
            <Field label="Make / Model"><input className="input" value={form.make} onChange={(e) => setForm({ ...form, make: e.target.value })} /></Field>
            <Field label="Seating Capacity"><input type="number" className="input" value={form.seatingCapacity} onChange={(e) => setForm({ ...form, seatingCapacity: e.target.value })} /></Field>
            <Field label="Monthly Rate (AED)"><input type="number" className="input" value={form.monthlyRate} onChange={(e) => setForm({ ...form, monthlyRate: e.target.value })} /></Field>
            <Field label="Daily Rate (AED)"><input type="number" className="input" value={form.dailyRate} onChange={(e) => setForm({ ...form, dailyRate: e.target.value })} /></Field>
            <PrimaryButton type="submit" full>Save vehicle</PrimaryButton>
          </form>
        </Modal>
      )}
    </div>
  );
}

/* ---------------- Clients ---------------- */
function ClientsPage({ data, persist, showToast, user }) {
  const [form, setForm] = useState(null);

  function startNew() { setForm({ id: null, name: "", address: "", phone: "", trn: "" }); }
  function remove(id) {
    if (!confirm("Remove this client? Existing invoices will remain but lose the client link.")) return;
    persist({ ...data, clients: data.clients.filter((c) => c.id !== id) });
    showToast("Client removed.");
  }
  function save(e) {
    e.preventDefault();
    if (!form.name) return showToast("Client name is required.", true);
    let clients;
    if (form.id) clients = data.clients.map((c) => (c.id === form.id ? form : c));
    else clients = [...data.clients, { ...form, id: uid() }];
    persist({ ...data, clients });
    setForm(null);
    showToast("Client saved.");
  }

  return (
    <div>
      <PageHeader title="Clients" subtitle="Companies you provide staff transport to.">
        {user.role === "admin" && <PrimaryButton onClick={startNew}><Plus size={15} /> Add client</PrimaryButton>}
      </PageHeader>
      <div className="grid gap-3">
        {data.clients.map((c) => (
          <div key={c.id} className="bg-white border border-[#E2E1DC] rounded-xl p-4 flex items-center justify-between">
            <div>
              <div className="font-medium">{c.name}</div>
              <div className="text-xs text-[#4A5568] mt-0.5">{c.address}</div>
              <div className="text-xs text-[#4A5568] font-mono mt-0.5">TRN {c.trn || "—"} · {c.phone || "—"}</div>
            </div>
            {user.role === "admin" && (
              <div className="flex gap-3">
                <button onClick={() => setForm(c)} className="text-xs underline">Edit</button>
                <button onClick={() => remove(c.id)} className="text-[#B3261E]"><Trash2 size={14} /></button>
              </div>
            )}
          </div>
        ))}
        {data.clients.length === 0 && <div className="text-sm text-[#4A5568]">No clients yet.</div>}
      </div>

      {form && (
        <Modal onClose={() => setForm(null)} title={form.id ? "Edit client" : "Add client"}>
          <form onSubmit={save} className="space-y-3">
            <Field label="Company Name"><input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
            <Field label="Address"><input className="input" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></Field>
            <Field label="Phone"><input className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
            <Field label="TRN"><input className="input" value={form.trn} onChange={(e) => setForm({ ...form, trn: e.target.value })} /></Field>
            <PrimaryButton type="submit" full>Save client</PrimaryButton>
          </form>
        </Modal>
      )}
    </div>
  );
}

/* ---------------- Invoices ---------------- */
function InvoicesPage({ data, persist, showToast }) {
  const [creating, setCreating] = useState(false);
  const [viewing, setViewing] = useState(null);

  function nextInvoiceNo(seq) {
    const year = new Date().getFullYear();
    return { invoiceNo: `${String(seq).padStart(5, "0")}/${year}`, seq };
  }

  function createInvoice(inv) {
    const invoices = [...data.invoices, inv];
    persist({ ...data, invoices, nextInvoiceSeq: data.nextInvoiceSeq + 1 });
    setCreating(false);
    showToast("Invoice created.");
    setViewing(inv);
  }
  function removeInvoice(id) {
    if (!confirm("Delete this invoice?")) return;
    persist({ ...data, invoices: data.invoices.filter((i) => i.id !== id) });
    showToast("Invoice deleted.");
  }

  if (viewing) return <InvoiceDocument invoice={viewing} data={data} onBack={() => setViewing(null)} />;

  return (
    <div>
      <PageHeader title="Invoices" subtitle="Generate and manage tax invoices.">
        <PrimaryButton onClick={() => setCreating(true)}><Plus size={15} /> New invoice</PrimaryButton>
      </PageHeader>

      <div className="bg-white border border-[#E2E1DC] rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-[#4A5568] uppercase tracking-wide bg-[#F7F6F3]">
              <th className="px-4 py-2.5">Invoice #</th><th className="px-4 py-2.5">Date</th>
              <th className="px-4 py-2.5">Client</th><th className="px-4 py-2.5">Net Amount</th><th className="px-4 py-2.5"></th>
            </tr>
          </thead>
          <tbody>
            {[...data.invoices].sort((a, b) => (a.date < b.date ? 1 : -1)).map((inv) => {
              const client = data.clients.find((c) => c.id === inv.clientId);
              return (
                <tr key={inv.id} className="border-t border-[#E2E1DC]">
                  <td className="px-4 py-2.5 font-mono">{inv.invoiceNo}</td>
                  <td className="px-4 py-2.5">{inv.date}</td>
                  <td className="px-4 py-2.5">{client?.name || "—"}</td>
                  <td className="px-4 py-2.5 font-mono font-medium">{formatAED(inv.total)}</td>
                  <td className="px-4 py-2.5 text-right">
                    <div className="flex justify-end gap-3">
                      <button onClick={() => setViewing(inv)} className="text-xs underline">View / Print</button>
                      <button onClick={() => removeInvoice(inv.id)} className="text-[#B3261E]"><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {data.invoices.length === 0 && <tr><td colSpan={5} className="px-4 py-6 text-center text-[#4A5568]">No invoices yet.</td></tr>}
          </tbody>
        </table>
      </div>

      {creating && (
        <InvoiceForm data={data} nextInvoiceNo={nextInvoiceNo} onCancel={() => setCreating(false)} onCreate={createInvoice} showToast={showToast} />
      )}
    </div>
  );
}

function InvoiceForm({ data, nextInvoiceNo, onCancel, onCreate, showToast }) {
  const [clientId, setClientId] = useState(data.clients[0]?.id || "");
  const [date, setDate] = useState(todayISO());
  const [lpo, setLpo] = useState("");
  const [remarks, setRemarks] = useState("");
  const [vatPercent, setVatPercent] = useState(5);
  const [items, setItems] = useState([emptyItem()]);

  function emptyItem() { return { id: uid(), vehicleId: "", description: "", qty: 1, unit: "month", unitPrice: 0 }; }
  function addItem() { setItems([...items, emptyItem()]); }
  function removeItem(id) { setItems(items.filter((i) => i.id !== id)); }
  function updateItem(id, patch) {
    setItems(items.map((i) => {
      if (i.id !== id) return i;
      const next = { ...i, ...patch };
      if (patch.vehicleId) {
        const v = data.vehicles.find((veh) => veh.id === patch.vehicleId);
        if (v) {
          next.description = `${v.seatingCapacity} seater AC bus (${v.vehicleNo}) with driver, without fuel`;
          next.unitPrice = next.unit === "day" ? v.dailyRate : v.monthlyRate;
        }
      }
      if (patch.unit) {
        const v = data.vehicles.find((veh) => veh.id === next.vehicleId);
        if (v) next.unitPrice = patch.unit === "day" ? v.dailyRate : v.monthlyRate;
      }
      return next;
    }));
  }

  const subtotal = items.reduce((s, i) => s + Number(i.qty || 0) * Number(i.unitPrice || 0), 0);
  const vatAmount = subtotal * (Number(vatPercent) / 100);
  const total = subtotal + vatAmount;

  function submit(e) {
    e.preventDefault();
    if (!clientId) return showToast("Select a client.", true);
    if (items.some((i) => !i.description)) return showToast("Every line needs a description.", true);
    const { invoiceNo, seq } = nextInvoiceNo(data.nextInvoiceSeq);
    onCreate({
      id: uid(), invoiceNo, seq, date, clientId, lpo, remarks,
      items: items.map((i) => ({ ...i, qty: Number(i.qty), unitPrice: Number(i.unitPrice), amount: Number(i.qty) * Number(i.unitPrice) })),
      vatPercent: Number(vatPercent), subtotal, vatAmount, total,
    });
  }

  return (
    <Modal onClose={onCancel} title="New invoice" wide>
      <form onSubmit={submit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Client">
            <select className="input" value={clientId} onChange={(e) => setClientId(e.target.value)}>
              {data.clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </Field>
          <Field label="Date"><input type="date" className="input" value={date} onChange={(e) => setDate(e.target.value)} /></Field>
          <Field label="LPO #"><input className="input" value={lpo} onChange={(e) => setLpo(e.target.value)} placeholder="e.g. ANSON-C33-RT-0093" /></Field>
          <Field label="VAT %"><input type="number" className="input" value={vatPercent} onChange={(e) => setVatPercent(e.target.value)} /></Field>
        </div>
        <Field label="Remarks"><input className="input" value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="e.g. June Bill" /></Field>

        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-[#4A5568] uppercase tracking-wide">Line items</span>
            <button type="button" onClick={addItem} className="text-xs text-[#14213D] underline flex items-center gap-1"><Plus size={12} /> Add line</button>
          </div>
          <div className="space-y-2">
            {items.map((it) => (
              <div key={it.id} className="border border-[#E2E1DC] rounded-lg p-3 grid grid-cols-12 gap-2 items-end">
                <div className="col-span-3">
                  <label className="label">Vehicle</label>
                  <select className="input" value={it.vehicleId} onChange={(e) => updateItem(it.id, { vehicleId: e.target.value })}>
                    <option value="">Custom</option>
                    {data.vehicles.map((v) => <option key={v.id} value={v.id}>{v.vehicleNo}</option>)}
                  </select>
                </div>
                <div className="col-span-4">
                  <label className="label">Description</label>
                  <input className="input" value={it.description} onChange={(e) => updateItem(it.id, { description: e.target.value })} />
                </div>
                <div className="col-span-1">
                  <label className="label">Qty</label>
                  <input type="number" className="input" value={it.qty} onChange={(e) => updateItem(it.id, { qty: e.target.value })} />
                </div>
                <div className="col-span-1">
                  <label className="label">Unit</label>
                  <select className="input" value={it.unit} onChange={(e) => updateItem(it.id, { unit: e.target.value })}>
                    {UNITS.map((u) => <option key={u} value={u}>{u}</option>)}
                  </select>
                </div>
                <div className="col-span-2">
                  <label className="label">Unit Price</label>
                  <input type="number" className="input" value={it.unitPrice} onChange={(e) => updateItem(it.id, { unitPrice: e.target.value })} />
                </div>
                <div className="col-span-1 flex justify-end">
                  <button type="button" onClick={() => removeItem(it.id)} className="text-[#B3261E] mb-1.5"><Trash2 size={14} /></button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-end">
          <div className="w-64 text-sm space-y-1">
            <div className="flex justify-between"><span className="text-[#4A5568]">Subtotal</span><span className="font-mono">{formatAED(subtotal)}</span></div>
            <div className="flex justify-between"><span className="text-[#4A5568]">VAT ({vatPercent}%)</span><span className="font-mono">{formatAED(vatAmount)}</span></div>
            <div className="flex justify-between font-semibold border-t border-[#E2E1DC] pt-1"><span>Net Amount</span><span className="font-mono">{formatAED(total)}</span></div>
          </div>
        </div>

        <PrimaryButton type="submit" full>Create invoice</PrimaryButton>
      </form>
    </Modal>
  );
}

function InvoiceDocument({ invoice, data, onBack }) {
  const client = data.clients.find((c) => c.id === invoice.clientId);
  return (
    <div>
      <div className="no-print flex items-center justify-between mb-4">
        <button onClick={onBack} className="text-sm underline">← Back to invoices</button>
        <PrimaryButton onClick={() => window.print()}><Printer size={15} /> Print / Save as PDF</PrimaryButton>
      </div>

      <div className="print-area bg-white border border-[#E2E1DC] rounded-xl p-8 max-w-3xl mx-auto" style={{ fontFamily: "Inter, sans-serif" }}>
        <div className="flex items-start justify-between border-b-2 border-[#14213D] pb-4">
          <div className="flex items-start gap-3">
            <Logo size={44} />
            <div>
              <div className="font-display font-bold text-lg leading-tight">{COMPANY.name}</div>
              <div className="text-xs text-[#4A5568] mt-1">{COMPANY.address}</div>
              <div className="text-xs text-[#4A5568]">{COMPANY.email} · {COMPANY.mobile}</div>
              <div className="text-xs text-[#4A5568] font-mono">TRN: {COMPANY.trn}</div>
            </div>
          </div>
          <div className="text-right">
            <div className="font-display font-bold text-xl tracking-wide">TAX INVOICE</div>
            <div className="text-xs text-[#4A5568] mt-1 font-mono">No. {invoice.invoiceNo}</div>
            <div className="text-xs text-[#4A5568] font-mono">Date: {invoice.date}</div>
            {invoice.lpo && <div className="text-xs text-[#4A5568] font-mono">LPO#: {invoice.lpo}</div>}
          </div>
        </div>

        <div className="mt-4 bg-[#F7F6F3] rounded-lg p-3">
          <div className="text-[10px] uppercase tracking-wide text-[#4A5568] mb-1">Bill to</div>
          <div className="font-semibold">{client?.name}</div>
          <div className="text-xs text-[#4A5568]">{client?.address}</div>
          <div className="text-xs text-[#4A5568] font-mono">TRN: {client?.trn || "—"} {client?.phone ? `· Tel: ${client.phone}` : ""}</div>
          {invoice.remarks && <div className="text-xs text-[#4A5568] mt-1">Remarks: {invoice.remarks}</div>}
        </div>

        <table className="w-full text-sm mt-4">
          <thead>
            <tr className="text-left text-[10px] uppercase tracking-wide text-white" style={{ background: "#14213D" }}>
              <th className="px-2 py-2 rounded-l">#</th><th className="px-2 py-2">Description</th>
              <th className="px-2 py-2">Qty</th><th className="px-2 py-2">Unit</th>
              <th className="px-2 py-2">Unit Price</th><th className="px-2 py-2 rounded-r text-right">Amount</th>
            </tr>
          </thead>
          <tbody>
            {invoice.items.map((it, idx) => (
              <tr key={it.id} className="border-b border-[#E2E1DC]">
                <td className="px-2 py-2">{idx + 1}</td>
                <td className="px-2 py-2">{it.description}</td>
                <td className="px-2 py-2 font-mono">{it.qty}</td>
                <td className="px-2 py-2">{it.unit}</td>
                <td className="px-2 py-2 font-mono">{formatAED(it.unitPrice)}</td>
                <td className="px-2 py-2 font-mono text-right">{formatAED(it.amount)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="flex justify-between items-end mt-4">
          <div className="text-xs text-[#4A5568] max-w-xs">
            <span className="font-medium">Amount in words:</span> {numberToWords(invoice.total)}
          </div>
          <div className="w-56 text-sm space-y-1">
            <div className="flex justify-between"><span className="text-[#4A5568]">Subtotal</span><span className="font-mono">{formatAED(invoice.subtotal)}</span></div>
            <div className="flex justify-between"><span className="text-[#4A5568]">VAT ({invoice.vatPercent}%)</span><span className="font-mono">{formatAED(invoice.vatAmount)}</span></div>
            <div className="flex justify-between font-semibold border-t border-[#14213D] pt-1"><span>Net Amount</span><span className="font-mono">{formatAED(invoice.total)}</span></div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-6 mt-8 pt-4 border-t border-[#E2E1DC]">
          <div>
            <div className="text-[10px] uppercase tracking-wide text-[#4A5568] mb-6">Signature & stamp — Bless Way</div>
            <div className="border-t border-[#14213D] pt-1 text-xs text-[#4A5568]">Authorized signatory</div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wide text-[#4A5568] mb-6">Receiver's signature</div>
            <div className="border-t border-[#14213D] pt-1 text-xs text-[#4A5568]">{client?.name}</div>
          </div>
        </div>

        <div className="mt-6 bg-[#F7F6F3] rounded-lg p-3 text-[11px] text-[#4A5568]">
          <div className="font-medium text-[#14213D] mb-1">For account transfers / cheque payment</div>
          Beneficiary Account Number: {COMPANY.bank.accountNumber}<br />
          Beneficiary Account Name: {COMPANY.bank.accountName}<br />
          Beneficiary IBAN: {COMPANY.bank.iban}
        </div>
      </div>
    </div>
  );
}

/* ---------------- Payments ---------------- */
function PaymentsPage({ data, persist, showToast }) {
  const [form, setForm] = useState(null);

  function startNew() { setForm({ clientId: data.clients[0]?.id || "", invoiceId: "", date: todayISO(), amount: "", method: "Bank Transfer", note: "" }); }
  function save(e) {
    e.preventDefault();
    if (!form.clientId || !form.amount) return showToast("Client and amount are required.", true);
    const payment = { ...form, id: uid(), amount: Number(form.amount) };
    persist({ ...data, payments: [...data.payments, payment] });
    setForm(null);
    showToast("Payment recorded.");
  }
  function remove(id) {
    if (!confirm("Delete this payment record?")) return;
    persist({ ...data, payments: data.payments.filter((p) => p.id !== id) });
    showToast("Payment removed.");
  }

  const clientInvoices = form ? data.invoices.filter((i) => i.clientId === form.clientId) : [];

  return (
    <div>
      <PageHeader title="Payments" subtitle="Every payment received, linked to a client and invoice.">
        <PrimaryButton onClick={startNew}><Plus size={15} /> Record payment</PrimaryButton>
      </PageHeader>

      <div className="bg-white border border-[#E2E1DC] rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-[#4A5568] uppercase tracking-wide bg-[#F7F6F3]">
              <th className="px-4 py-2.5">Date</th><th className="px-4 py-2.5">Client</th>
              <th className="px-4 py-2.5">Invoice</th><th className="px-4 py-2.5">Method</th>
              <th className="px-4 py-2.5">Amount</th><th className="px-4 py-2.5"></th>
            </tr>
          </thead>
          <tbody>
            {[...data.payments].sort((a, b) => (a.date < b.date ? 1 : -1)).map((p) => {
              const client = data.clients.find((c) => c.id === p.clientId);
              const inv = data.invoices.find((i) => i.id === p.invoiceId);
              return (
                <tr key={p.id} className="border-t border-[#E2E1DC]">
                  <td className="px-4 py-2.5">{p.date}</td>
                  <td className="px-4 py-2.5">{client?.name || "—"}</td>
                  <td className="px-4 py-2.5 font-mono">{inv?.invoiceNo || "—"}</td>
                  <td className="px-4 py-2.5">{p.method}</td>
                  <td className="px-4 py-2.5 font-mono font-medium text-[#2A9D8F]">{formatAED(p.amount)}</td>
                  <td className="px-4 py-2.5 text-right"><button onClick={() => remove(p.id)} className="text-[#B3261E]"><Trash2 size={14} /></button></td>
                </tr>
              );
            })}
            {data.payments.length === 0 && <tr><td colSpan={6} className="px-4 py-6 text-center text-[#4A5568]">No payments recorded yet.</td></tr>}
          </tbody>
        </table>
      </div>

      {form && (
        <Modal onClose={() => setForm(null)} title="Record payment">
          <form onSubmit={save} className="space-y-3">
            <Field label="Client">
              <select className="input" value={form.clientId} onChange={(e) => setForm({ ...form, clientId: e.target.value, invoiceId: "" })}>
                {data.clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </Field>
            <Field label="Against invoice (optional)">
              <select className="input" value={form.invoiceId} onChange={(e) => setForm({ ...form, invoiceId: e.target.value })}>
                <option value="">— General payment —</option>
                {clientInvoices.map((i) => <option key={i.id} value={i.id}>{i.invoiceNo} · {formatAED(i.total)}</option>)}
              </select>
            </Field>
            <Field label="Date"><input type="date" className="input" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></Field>
            <Field label="Amount (AED)"><input type="number" className="input" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></Field>
            <Field label="Method">
              <select className="input" value={form.method} onChange={(e) => setForm({ ...form, method: e.target.value })}>
                {["Bank Transfer", "Cheque", "Cash", "Card"].map((m) => <option key={m}>{m}</option>)}
              </select>
            </Field>
            <Field label="Note"><input className="input" value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} /></Field>
            <PrimaryButton type="submit" full>Save payment</PrimaryButton>
          </form>
        </Modal>
      )}
    </div>
  );
}

/* ---------------- Statements ---------------- */
function StatementsPage({ data }) {
  const [clientId, setClientId] = useState(data.clients[0]?.id || "");
  const client = data.clients.find((c) => c.id === clientId);

  const rows = useMemo(() => {
    const invs = data.invoices.filter((i) => i.clientId === clientId).map((i) => ({ type: "invoice", date: i.date, ref: i.invoiceNo, amount: i.total }));
    const pays = data.payments.filter((p) => p.clientId === clientId).map((p) => ({ type: "payment", date: p.date, ref: p.method, amount: p.amount }));
    const all = [...invs, ...pays].sort((a, b) => (a.date > b.date ? 1 : -1));
    let balance = 0;
    return all.map((r) => {
      balance += r.type === "invoice" ? r.amount : -r.amount;
      return { ...r, balance };
    });
  }, [data, clientId]);

  const totalInvoiced = rows.filter((r) => r.type === "invoice").reduce((s, r) => s + r.amount, 0);
  const totalReceived = rows.filter((r) => r.type === "payment").reduce((s, r) => s + r.amount, 0);

  return (
    <div>
      <PageHeader title="Statements" subtitle="Invoiced vs received, per client.">
        <div className="flex gap-2">
          <select className="input" value={clientId} onChange={(e) => setClientId(e.target.value)}>
            {data.clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <PrimaryButton onClick={() => window.print()}><Printer size={15} /> Print</PrimaryButton>
        </div>
      </PageHeader>

      <div className="print-area bg-white border border-[#E2E1DC] rounded-xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <Logo size={32} />
          <div>
            <div className="font-display font-semibold">{COMPANY.name}</div>
            <div className="text-xs text-[#4A5568]">Statement of Account — {client?.name}</div>
          </div>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-[#4A5568] uppercase tracking-wide bg-[#F7F6F3]">
              <th className="px-3 py-2">Date</th><th className="px-3 py-2">Type</th><th className="px-3 py-2">Reference</th>
              <th className="px-3 py-2 text-right">Amount</th><th className="px-3 py-2 text-right">Balance</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, idx) => (
              <tr key={idx} className="border-t border-[#E2E1DC]">
                <td className="px-3 py-2">{r.date}</td>
                <td className="px-3 py-2">{r.type === "invoice" ? "Invoice" : "Payment"}</td>
                <td className="px-3 py-2 font-mono">{r.ref}</td>
                <td className={`px-3 py-2 text-right font-mono ${r.type === "payment" ? "text-[#2A9D8F]" : ""}`}>
                  {r.type === "payment" ? "-" : ""}{formatAED(r.amount)}
                </td>
                <td className="px-3 py-2 text-right font-mono font-medium">{formatAED(r.balance)}</td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={5} className="px-3 py-6 text-center text-[#4A5568]">No activity for this client yet.</td></tr>}
          </tbody>
          <tfoot>
            <tr className="border-t-2 border-[#14213D] font-semibold">
              <td className="px-3 py-2" colSpan={3}>Total</td>
              <td className="px-3 py-2 text-right font-mono">{formatAED(totalInvoiced)} invoiced / {formatAED(totalReceived)} received</td>
              <td className="px-3 py-2 text-right font-mono">{formatAED(totalInvoiced - totalReceived)}</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}

/* ---------------- Expenses ---------------- */
function ExpensesPage({ data, persist, showToast }) {
  const [form, setForm] = useState(null);
  const [filter, setFilter] = useState("All");

  function startNew() { setForm({ category: "Vehicle Maintenance", vehicleId: "", date: todayISO(), amount: "", vendor: "", note: "" }); }
  function save(e) {
    e.preventDefault();
    if (!form.category || !form.amount) return showToast("Category and amount are required.", true);
    const expense = { ...form, id: uid(), amount: Number(form.amount) };
    persist({ ...data, expenses: [...(data.expenses || []), expense] });
    setForm(null);
    showToast("Expense recorded.");
  }
  function remove(id) {
    if (!confirm("Delete this expense?")) return;
    persist({ ...data, expenses: data.expenses.filter((e) => e.id !== id) });
    showToast("Expense removed.");
  }

  const expenses = data.expenses || [];
  const shown = filter === "All" ? expenses : expenses.filter((e) => e.category === filter);
  const sorted = [...shown].sort((a, b) => (a.date < b.date ? 1 : -1));
  const total = shown.reduce((s, e) => s + e.amount, 0);
  const needsVehicle = form && (form.category === "Vehicle Maintenance" || form.category === "Fuel" || form.category === "Insurance");

  return (
    <div>
      <PageHeader title="Expenses" subtitle="Maintenance, fuel, utility bills, office costs — everything that eats into profit.">
        <PrimaryButton onClick={startNew}><Plus size={15} /> Add expense</PrimaryButton>
      </PageHeader>

      <div className="no-print flex items-center gap-2 mb-4 flex-wrap">
        {["All", ...EXPENSE_CATEGORIES].map((c) => (
          <button key={c} onClick={() => setFilter(c)}
            className={`px-3 py-1.5 rounded-full text-xs border transition ${filter === c ? "bg-[#14213D] text-white border-[#14213D]" : "border-[#E2E1DC] text-[#4A5568] hover:border-[#14213D]"}`}>
            {c}
          </button>
        ))}
      </div>

      <div className="bg-white border border-[#E2E1DC] rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-[#4A5568] uppercase tracking-wide bg-[#F7F6F3]">
              <th className="px-4 py-2.5">Date</th><th className="px-4 py-2.5">Category</th>
              <th className="px-4 py-2.5">Vehicle</th><th className="px-4 py-2.5">Vendor / Note</th>
              <th className="px-4 py-2.5 text-right">Amount</th><th className="px-4 py-2.5"></th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((e) => {
              const v = data.vehicles.find((veh) => veh.id === e.vehicleId);
              return (
                <tr key={e.id} className="border-t border-[#E2E1DC]">
                  <td className="px-4 py-2.5">{e.date}</td>
                  <td className="px-4 py-2.5">{e.category}</td>
                  <td className="px-4 py-2.5 font-mono">{v ? v.vehicleNo : "—"}</td>
                  <td className="px-4 py-2.5 text-[#4A5568]">{e.vendor}{e.vendor && e.note ? " · " : ""}{e.note}</td>
                  <td className="px-4 py-2.5 text-right font-mono font-medium text-[#B3261E]">{formatAED(e.amount)}</td>
                  <td className="px-4 py-2.5 text-right"><button onClick={() => remove(e.id)} className="text-[#B3261E]"><Trash2 size={14} /></button></td>
                </tr>
              );
            })}
            {sorted.length === 0 && <tr><td colSpan={6} className="px-4 py-6 text-center text-[#4A5568]">No expenses recorded yet.</td></tr>}
          </tbody>
          {sorted.length > 0 && (
            <tfoot>
              <tr className="border-t-2 border-[#14213D] font-semibold">
                <td className="px-4 py-2.5" colSpan={4}>{filter === "All" ? "Total" : `Total — ${filter}`}</td>
                <td className="px-4 py-2.5 text-right font-mono">{formatAED(total)}</td>
                <td></td>
              </tr>
            </tfoot>
          )}
        </table>
      </div>

      {form && (
        <Modal onClose={() => setForm(null)} title="Add expense">
          <form onSubmit={save} className="space-y-3">
            <Field label="Category">
              <select className="input" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                {EXPENSE_CATEGORIES.map((c) => <option key={c}>{c}</option>)}
              </select>
            </Field>
            {needsVehicle && (
              <Field label="Vehicle (optional)">
                <select className="input" value={form.vehicleId} onChange={(e) => setForm({ ...form, vehicleId: e.target.value })}>
                  <option value="">— Fleet-wide / not vehicle-specific —</option>
                  {data.vehicles.map((v) => <option key={v.id} value={v.id}>{v.vehicleNo} · {v.make}</option>)}
                </select>
              </Field>
            )}
            <Field label="Date"><input type="date" className="input" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></Field>
            <Field label="Amount (AED)"><input type="number" className="input" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></Field>
            <Field label="Vendor / Supplier"><input className="input" value={form.vendor} onChange={(e) => setForm({ ...form, vendor: e.target.value })} placeholder="e.g. Al Futtaim Service Centre" /></Field>
            <Field label="Note"><input className="input" value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} placeholder="e.g. Oil change + brake pads" /></Field>
            <PrimaryButton type="submit" full>Save expense</PrimaryButton>
          </form>
        </Modal>
      )}
    </div>
  );
}

/* ---------------- Profit & Loss ---------------- */
function ProfitLossPage({ data }) {
  const revenue = totalRevenue(data);
  const expenses = totalExpenses(data);
  const profit = revenue - expenses;
  const margin = revenue > 0 ? (profit / revenue) * 100 : 0;

  const byCategory = useMemo(() => {
    const map = {};
    (data.expenses || []).forEach((e) => { map[e.category] = (map[e.category] || 0) + e.amount; });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [data]);

  const byVehicle = useMemo(() => {
    return data.vehicles.map((v) => {
      const rev = data.invoices.reduce((s, inv) => s + inv.items.filter((it) => it.vehicleId === v.id).reduce((s2, it) => s2 + it.amount, 0), 0);
      const cost = (data.expenses || []).filter((e) => e.vehicleId === v.id).reduce((s, e) => s + e.amount, 0);
      return { vehicle: v, revenue: rev, cost, net: rev - cost };
    }).sort((a, b) => b.net - a.net);
  }, [data]);

  const byMonth = useMemo(() => {
    const map = {};
    data.invoices.forEach((i) => { const k = monthKey(i.date); map[k] = map[k] || { revenue: 0, expenses: 0 }; map[k].revenue += i.subtotal; });
    (data.expenses || []).forEach((e) => { const k = monthKey(e.date); map[k] = map[k] || { revenue: 0, expenses: 0 }; map[k].expenses += e.amount; });
    return Object.entries(map).sort((a, b) => (a[0] < b[0] ? 1 : -1)).slice(0, 12);
  }, [data]);

  return (
    <div>
      <PageHeader title="Profit & Loss" subtitle="Revenue (pre-VAT) minus fleet, maintenance, and office costs.">
        <PrimaryButton onClick={() => window.print()}><Printer size={15} /> Print</PrimaryButton>
      </PageHeader>

      <div className="print-area">
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-white border border-[#E2E1DC] rounded-xl p-4">
            <div className="text-xs text-[#4A5568] mb-1">Revenue (ex-VAT)</div>
            <div className="font-mono text-xl font-semibold">{formatAED(revenue)}</div>
          </div>
          <div className="bg-white border border-[#E2E1DC] rounded-xl p-4">
            <div className="text-xs text-[#4A5568] mb-1">Expenses</div>
            <div className="font-mono text-xl font-semibold text-[#B3261E]">{formatAED(expenses)}</div>
          </div>
          <div className="bg-white border border-[#E2E1DC] rounded-xl p-4">
            <div className="text-xs text-[#4A5568] mb-1">Net Profit · {margin.toFixed(1)}% margin</div>
            <div className={`font-mono text-xl font-semibold ${profit >= 0 ? "text-[#2A9D8F]" : "text-[#B3261E]"}`}>{formatAED(profit)}</div>
          </div>
        </div>

        <h2 className="font-display text-lg font-semibold mb-3">Expenses by category</h2>
        <div className="bg-white border border-[#E2E1DC] rounded-xl overflow-hidden mb-6">
          {byCategory.length === 0 ? (
            <div className="p-4 text-sm text-[#4A5568]">No expenses logged yet.</div>
          ) : byCategory.map(([cat, amt]) => (
            <div key={cat} className="flex items-center justify-between px-4 py-2.5 border-b border-[#E2E1DC] last:border-0 text-sm">
              <span className="flex items-center gap-2"><Wrench size={13} className="text-[#4A5568]" /> {cat}</span>
              <span className="font-mono">{formatAED(amt)} <span className="text-[#4A5568] text-xs">({expenses > 0 ? ((amt / expenses) * 100).toFixed(0) : 0}%)</span></span>
            </div>
          ))}
        </div>

        <h2 className="font-display text-lg font-semibold mb-3">Profitability by vehicle</h2>
        <div className="bg-white border border-[#E2E1DC] rounded-xl overflow-hidden mb-6">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-[#4A5568] uppercase tracking-wide bg-[#F7F6F3]">
                <th className="px-4 py-2.5">Vehicle</th><th className="px-4 py-2.5 text-right">Revenue</th>
                <th className="px-4 py-2.5 text-right">Maintenance / Fuel / Insurance</th><th className="px-4 py-2.5 text-right">Net</th>
              </tr>
            </thead>
            <tbody>
              {byVehicle.map((row) => (
                <tr key={row.vehicle.id} className="border-t border-[#E2E1DC]">
                  <td className="px-4 py-2.5 font-mono">{row.vehicle.vehicleNo}</td>
                  <td className="px-4 py-2.5 text-right font-mono">{formatAED(row.revenue)}</td>
                  <td className="px-4 py-2.5 text-right font-mono text-[#B3261E]">{formatAED(row.cost)}</td>
                  <td className={`px-4 py-2.5 text-right font-mono font-semibold ${row.net >= 0 ? "text-[#2A9D8F]" : "text-[#B3261E]"}`}>{formatAED(row.net)}</td>
                </tr>
              ))}
              {byVehicle.length === 0 && <tr><td colSpan={4} className="px-4 py-6 text-center text-[#4A5568]">No vehicles yet.</td></tr>}
            </tbody>
          </table>
        </div>
        <p className="text-xs text-[#4A5568] -mt-4 mb-6">Vehicle revenue only counts invoice lines where a specific vehicle was selected — custom line items aren't attributed to a vehicle.</p>

        <h2 className="font-display text-lg font-semibold mb-3">Monthly trend</h2>
        <div className="bg-white border border-[#E2E1DC] rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-[#4A5568] uppercase tracking-wide bg-[#F7F6F3]">
                <th className="px-4 py-2.5">Month</th><th className="px-4 py-2.5 text-right">Revenue</th>
                <th className="px-4 py-2.5 text-right">Expenses</th><th className="px-4 py-2.5 text-right">Net</th>
              </tr>
            </thead>
            <tbody>
              {byMonth.map(([m, v]) => (
                <tr key={m} className="border-t border-[#E2E1DC]">
                  <td className="px-4 py-2.5 font-mono">{m}</td>
                  <td className="px-4 py-2.5 text-right font-mono">{formatAED(v.revenue)}</td>
                  <td className="px-4 py-2.5 text-right font-mono text-[#B3261E]">{formatAED(v.expenses)}</td>
                  <td className={`px-4 py-2.5 text-right font-mono font-semibold ${v.revenue - v.expenses >= 0 ? "text-[#2A9D8F]" : "text-[#B3261E]"}`}>{formatAED(v.revenue - v.expenses)}</td>
                </tr>
              ))}
              {byMonth.length === 0 && <tr><td colSpan={4} className="px-4 py-6 text-center text-[#4A5568]">No activity yet.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* ---------------- shared UI bits ---------------- */
function PageHeader({ title, subtitle, children }) {
  return (
    <div className="flex items-center justify-between mb-5">
      <div>
        <h1 className="font-display text-2xl font-semibold">{title}</h1>
        <p className="text-sm text-[#4A5568] mt-0.5">{subtitle}</p>
      </div>
      <div className="no-print">{children}</div>
    </div>
  );
}
function PrimaryButton({ children, full, ...props }) {
  return (
    <button {...props} className={`bg-[#14213D] hover:bg-[#1d2f57] text-white rounded-lg px-4 py-2 text-sm font-medium flex items-center justify-center gap-1.5 transition ${full ? "w-full" : ""}`}>
      {children}
    </button>
  );
}
function Field({ label, children }) {
  return <div><label className="label block mb-1">{label}</label>{children}</div>;
}
function Modal({ title, children, onClose, wide }) {
  return (
    <div className="no-print fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className={`bg-white rounded-2xl p-6 w-full ${wide ? "max-w-2xl" : "max-w-md"} max-h-[85vh] overflow-y-auto`} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display font-semibold text-lg">{title}</h3>
          <button onClick={onClose}><X size={18} className="text-[#4A5568]" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}
